package com.ems.customexceptions;

public class InvalidNumberException extends Exception{
	public InvalidNumberException(String msg) {
		super(msg);
	}
}

