package com.ems.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.ems.customexceptions.InvalidNumberException;
import com.ems.operations.AttendanceOperations;
import com.ems.operations.DepartmentOperations;
import com.ems.operations.EmployeeOperations;
import com.ems.operations.ManagerOperations;
import com.ems.operations.ProjectOperations;
import com.ems.operations.SalaryOperations;

public class App {
	public static void printOptions() {
		System.out.println("------------------------------------");
        System.out.println("Select an option:");
        System.out.println("1. Manage Employees");
        System.out.println("2. Manage Departments");
        System.out.println("3. Manage Projects");
        System.out.println("4. Manage Managers");
        System.out.println("5. Manage Attendance");
        System.out.println("6. Manage Salaries");
        System.out.println("0. Exit");

        System.out.println("------------------------------------");
	}
	
	
	
	public static void main(String[] args) throws InvalidNumberException {
	    try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
	        System.out.println("------------------------------------");
	        System.out.println("-----Employee Management System-----");
	        int i=0;
	        while (true) {
	            printOptions();
	            int choice;
	            try {
	                choice = Integer.parseInt(br.readLine());
	                for(i=0;i<1;i++) {
	                	System.out.println("Connecting to Database....");
	                }
	                switch (choice) {
	                    case 1:
	                        EmployeeOperations.manageEmployees(br);
	                        break;
	                    case 2:
	                        DepartmentOperations.manageDepartments(br);
	                        break;
	                    case 3:
	                        ProjectOperations.manageProjects(br);
	                        break;
	                    case 4:
	                        ManagerOperations.manageManager(br);
	                        break;
	                    case 5:
	                        AttendanceOperations.manageAttendance(br);
	                        break;
	                    case 6:
	                        SalaryOperations.manageSalaries(br);
	                        break;
	                    case 0:
	                        System.out.println("==========={Terminated}=============");
	                        return;
	                    default:
	                        System.out.println("Invalid choice. Please try again.");
	                }
	            } catch (NumberFormatException e) {
	                System.out.println("Invalid input format. Please enter a number.");
	            }
	        }
	    } catch (IOException e) {
	        System.out.println("Error occurred while processing input. Exiting program.");
	        e.printStackTrace();
	    }
	}

    
}
