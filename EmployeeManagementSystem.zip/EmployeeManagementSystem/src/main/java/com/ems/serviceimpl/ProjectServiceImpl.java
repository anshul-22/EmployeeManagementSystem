package com.ems.serviceimpl;

import com.ems.entities.Project;
import com.ems.entities.Manager;
import com.ems.service.ProjectService;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;
import java.util.List;

public class ProjectServiceImpl implements ProjectService {
    private final SessionFactory sessionFactory;

    public ProjectServiceImpl() {
        // Initialize Hibernate session factory
        Configuration config = new Configuration().configure("hibernate.cfg.xml");
        sessionFactory = config.buildSessionFactory();
    }

    @Override
    public void addProject(String projectId, String projectName, Date startDate, Date endDate, String status, String managerId) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = new Project();
            project.setProjectId(projectId);
            project.setProjectName(projectName);
            project.setStartDate(startDate);
            project.setEndDate(endDate);
            project.setStatus(status);

            // Fetch manager by ID and set it to project
            Manager manager = session.get(Manager.class, managerId);
            project.setManager(manager);
            session.save(project);
            transaction.commit();
        }
    }

    @Override
    public Project getProjectById(String projectId) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Project.class, projectId);
        }
    }

    @Override
    public List<Project> getAllProjects() {
        try (Session session = sessionFactory.openSession()) {
            Query<Project> query = session.createQuery("FROM Project", Project.class);
            return query.list();
        }
    }

    @Override
    public void updateProjectName(String projectId, String newName) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                project.setProjectName(newName);
                session.update(project);
                transaction.commit();
            }
        }
    }

    @Override
    public void updateProjectStartDate(String projectId, Date newStartDate) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                project.setStartDate(newStartDate);
                session.update(project);
                transaction.commit();
            }
        }
    }

    @Override
    public void updateProjectEndDate(String projectId, Date newEndDate) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                project.setEndDate(newEndDate);
                session.update(project);
                transaction.commit();
            }
        }
    }

    @Override
    public void updateProjectStatus(String projectId, String newStatus) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                project.setStatus(newStatus);
                session.update(project);
                transaction.commit();
            }
        }
    }

    @Override
    public void updateProjectManager(String projectId, String newManagerId) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                Manager newManager = session.get(Manager.class, newManagerId);
                project.setManager(newManager);
                session.update(project);
                transaction.commit();
            }
        }
    }

    @Override
    public void deleteProject(String projectId) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            Project project = session.get(Project.class, projectId);
            if (project != null) {
                session.delete(project);
                transaction.commit();
            }
        }
    }
}
